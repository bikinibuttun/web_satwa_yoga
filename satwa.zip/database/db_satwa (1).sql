-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 13, 2023 at 06:24 AM
-- Server version: 5.5.39
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_satwa`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_akun`
--

CREATE TABLE IF NOT EXISTS `tb_akun` (
  `id_akun` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `no_telp` varchar(50) NOT NULL,
  `surel` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_akun`
--

INSERT INTO `tb_akun` (`id_akun`, `password`, `nama`, `no_telp`, `surel`) VALUES
('Yoga', 'yoga', 'Yoga Pratama', '0831069999083', 'yp001@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tb_saran`
--

CREATE TABLE IF NOT EXISTS `tb_saran` (
`id_saran` int(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `surel` varchar(50) NOT NULL,
  `isi` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tb_saran`
--

INSERT INTO `tb_saran` (`id_saran`, `nama`, `surel`, `isi`) VALUES
(1, 'Regi Saepuloh', 'rxking@gmail.com', 'aa');

-- --------------------------------------------------------

--
-- Table structure for table `tb_satwa`
--

CREATE TABLE IF NOT EXISTS `tb_satwa` (
`id_satwa` int(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `gambar` varchar(500) NOT NULL,
  `biografi` text NOT NULL,
  `jumlah` varchar(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `tb_satwa`
--

INSERT INTO `tb_satwa` (`id_satwa`, `nama`, `gambar`, `biografi`, `jumlah`) VALUES
(1, 'Badak Jawa', 'badak_jawa.jpg', 'Badak Jawa (Rhinoceros sondaicus), disebut juga Badak sumbu, Badak sunda (sesuai dengan nama latinnya) atau badak bercula satu kecil, adalah sebuah anggota famili Rhinocerotidae dan merupakan salah satu dari lima spesies badak yang masih ada. Badak India, yang berbagi genus yang sama, memilki kulit bermosaik yang menyerupai baju baja, yang memiliki kemiripan dengan badak Jawa meskipun ukurannya lebih besar. Badak Jawa memiliki badan dengan panjang 3,1–3,2 m dan tinggi 1,4–1,7 m. Badak Jawa memiliki ukuran cula terkecil dibandingkan dengan cula spesies-spesies badak lainnya sedangkan Badak Jawa betina tidak memiliki cula sama sekali.', 'pada tahun 2019 adalah 68 individu,'),
(2, 'Kanguru Pohon Wondiwoi', 'kangguru.jpg', 'adalah spesies mamalia dalam genus Dendrolagus. Sampai saat ini hanya diketahui dari spesimen tunggal yang dikumpulkan pada tahun 1928.[1] Satu-satunya spesimen yang diketahui adalah jantan dengan berat 9,25 kg.[1] D. mayri ditemukan di Semenanjung Wondiwoi di Papua Barat di ketinggian antara 1600 m dalam Hutan Montane. Diperkirakan bahwa kanguru-pohon Wondiwoi dapat menempati area seluas 300 km².[1] Pelestarian Satwa Liar Global, badan amal pelestarian margasatwa, mendaftarkan Kangaroo Pohon Wondiwoi sebagai salah satu dari "25 Spesies Hilang Paling Dicari".', 'kanguru pohon ini sekitar 50 ekor individu saja.'),
(3, 'Pesut Mahakam', 'pesut.jpg', 'Pesut mahakam adalah sejenis hewan mamalia yang sering disebut lumba-lumba air tawar yang berstatus terancam punah. Pesut ini dinamakan pesut mahakam karena banyak ditemukan di perairan Sungai Mahakam, tetapi kalangan peneliti barat lebih mengenal hewan ini dengan nama Irrawaddy Dolphin.', 'Pesut Mahakam kurang lebih dari 80 ekor saat ini.'),
(4, 'Macan tutul', 'macan.jpg', 'Macan tutul (Latin: Panthera pardus) atau Harimau Bintang adalah salah satu dari empat kucing besar. Hewan ini dikenal juga dengan sebutan harimau dahan karena kemampuannya memanjat. ', 'tersisa 300 ekor termasuk yang hidup di gunung Muria'),
(5, 'Badak Sumatera', 'badak.jpg', 'Badak sumatra, juga dikenal sebagai badak berambut atau badak Asia bercula dua, merupakan spesies langka dari famili Rhinocerotidae dan termasuk salah satu dari lima spesies badak yang masih lestari. Badak sumatra merupakan satu-satunya spesies yang tersisa dari genus Dicerorhinus. ', 'populasinya diperkirakan tidak lebih dari 275 ekor.'),
(6, 'Kura Kura Hutan Sumatera', 'kura.jpg', 'Kura-kura Hutan Sulawesi (Leucocephalon yuwonoi) atau Sulawesi Forest Turtle; Kura-kura endemik sulawesi yang pernah terdaftar sebagai The World’s 25 Most Endangered Tortoises and Freshwater.', 'dengan populasi kurang dari 250 ekor.'),
(7, 'Elang Flores', 'elang.jpg', 'Elang Flores merupakan salah satu jenis raptor endemik yang dipunyai Indonesia dari keluarga Accipitridae dan Genus Nisaetus. Elang flores sebelumnya dianggap sebagai ras elang brontok tetapi Gjershaug et al menunjukkan bahwa perbedaan morfologis yang signifikan antara bentuk ini denga elang brontok.', 'populasi elang Flores di alam diperkirakan hanya 250 ekor.'),
(8, 'Bawean', 'bawean.jpg', 'bawean adalah sejenis rusa yang saat ini hanya ditemukan di Pulau Bawean di tengah Laut Jawa, Secara administratif pulau ini termasuk dalam Kabupaten Gresik, Provinsi Jawa Timur, Indonesia. Spesies ini tergolong langka dan diklasifikasikan sebagai "terancam punah" oleh Uni Internasional untuk Konservasi Alam.', 'Populasinya antara 250–300 saja.'),
(9, 'Burung cendrawasih', 'wasih.jpg', 'Burung Cenderawasih adalah anggota famili Paradisaeidae dari ordo Passeriformes. Cenderawasih biasanya ditemukan di Indonesia seperti di bagian Timur Papua, Papua Nugini, pulau-pulau selat Torres, dan Australia timur.', 'populasi burung Cenderawasih (P.apoda) adalah sebanyak 28 ekor.'),
(10, 'Harimau Sumatera', 'harimau.jpg', 'Harimau adalah kucing terbesar di muka bumi. Harimau Sumatera merupakan salah satu sub-spesies harimau yang masih bertahan hidup hingga saat ini.', 'populasi harimau sumatera hanya sekitar 210 individu.'),
(11, 'Burung Merak', 'merak.jpg', 'Merak adalah tiga spesies burung dalam genus Pavo dan Afropavo dari familia ayam hutan, Phasianidae. Burung jantannya memiliki bulu ekor yang indah yang dapat dikembangkan untuk menarik perhatian merak betina. Ketiga spesies tersebut adalah: Merak India, Pavo cristatus Merak Hijau, Pavo muticus', 'Indonesia berada di angka 800 ekor.'),
(12, 'Elang Jawa', 'elangjawa.jpg', 'Elang jawa adalah salah satu spesies elang berukuran sedang dari keluarga Accipitridae dan genus Nisaetus yang endemik di Pulau Jawa. Satwa ini dianggap identik dengan lambang negara Republik Indonesia, yaitu Garuda. Dan sejak 1992, burung ini ditetapkan sebagai maskot satwa langka Indonesia ', 'total populasi ada 34 individu.'),
(13, 'Orangutan Tapanuli', 'orangutan.jpg', 'Orangutan Kalimantan, Pongo pygmaeus, adalah spesies orangutan asli pulau Kalimantan. Bersama dengan orangutan Sumatra yang lebih kecil, orangutan Kalimantan masuk kedalam genus pongo yang dapat ditemui di Asia.', 'diperkirakan hanya sekitar 800 individu.\r\n'),
(14, 'Jalak Bali', 'jalak.jpg', 'Jalak Bali adalah sejenis burung pengicau berukuran sedang, dengan panjang lebih kurang 25 cm, dari suku Sturnidae. Ia turut dikenali sebagai Curik Ketimbang Jalak. Jalak Bali hanya ditemukan di hutan bagian barat Pulau Bali dan merupakan hewan endemik Indonesia.', 'November 2022 mencapai 560 ekor.'),
(15, 'Owa Jawa', 'owa.jpg', 'Owa jawa adalah sejenis primata anggota suku Hylobatidae. kera ini adalah spesies owa yang paling langka di dunia. Owa jawa menyebar terbatas di Jawa bagian barat.', 'populasi tersisa antara 1.000 – 2.000 ekor.'),
(16, 'Moyet Kedih', 'kedih.jpg', 'Kedih adalah spesies primata yang tergolong dalam famili Cercopithecidae. Hewan ini merupakan hewan endemik di utara Sumatra, Indonesia. Habitat alaminya adalah hutan tropis kering atau subtropis. Hewan ini terancam oleh pengrusakan habitat. Nama aslinya adalah reungkah di Aceh dan kedih di Alas.\r\n', 'kedih dengan total jumlah individu 34 ekor.'),
(17, 'Ikan Arwana Merah', 'arwana.jpg', 'Arwana Asia, atau Siluk Merah adalah salah satu spesies ikan air tawar dari Asia Tenggara. Arwana Asia memiliki badan yang panjang; sirip dubur yang terletak jauh di belakang badan. Ikan Arwana Asia adalah ikan bertulang dari keluarga Osteoglossidae, yang juga dikenal sebagai bonytongues.', ' tahun 2019 sebanyak 469 ekor.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_akun`
--
ALTER TABLE `tb_akun`
 ADD PRIMARY KEY (`id_akun`);

--
-- Indexes for table `tb_saran`
--
ALTER TABLE `tb_saran`
 ADD PRIMARY KEY (`id_saran`);

--
-- Indexes for table `tb_satwa`
--
ALTER TABLE `tb_satwa`
 ADD PRIMARY KEY (`id_satwa`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_saran`
--
ALTER TABLE `tb_saran`
MODIFY `id_saran` int(50) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tb_satwa`
--
ALTER TABLE `tb_satwa`
MODIFY `id_satwa` int(50) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
